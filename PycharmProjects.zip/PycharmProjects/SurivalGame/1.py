import random
import time

while True:
    line = ""
    for i in range(20):
        line += str(random.randint(0,9)) + ""

    print(line)
    time.sleep(0.01)