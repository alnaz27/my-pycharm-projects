import pygame
import random
import sys

# Инициализация
pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Выживание")
clock = pygame.time.Clock()

# Загрузка и подгонка картинок
background = pygame.image.load("fon.jpg")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

player_img = pygame.image.load("igrok.png")
player_size = 30
player_img = pygame.transform.scale(player_img, (player_size, player_size))

player_x, player_y = 400, 300
speed = 5

# Враги
enemy_img = pygame.image.load("vrag.png")
enemy_size = 25
enemy_img = pygame.transform.scale(enemy_img, (enemy_size, enemy_size))

enemies = []
enemy_speed = 2
spawn_delay = 0

# Очки и шрифты
score = 0
font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 74)  # Крупный шрифт для финала

# Состояния игры
running = True
game_over = False  # Переменная, которая отвечает за экран проигрыша

# Главный цикл игры
while running:
    clock.tick(60)

    # 1. Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # Если игра окончена, нажатие на любую клавишу закроет её
        if game_over and event.type == pygame.KEYDOWN:
            running = False

    # Если играем (еще не проиграли)
    if not game_over:
        # 2. Управление игроком
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= speed
        if keys[pygame.K_RIGHT] and player_x < WIDTH - player_size:
            player_x += speed
        if keys[pygame.K_UP] and player_y > 0:
            player_y -= speed
        if keys[pygame.K_DOWN] and player_y < HEIGHT - player_size:
            player_y += speed

        # 3. Спавн врагов
        spawn_delay += 1
        if spawn_delay >= 60:
            spawn_delay = 0
            x = random.choice([0, WIDTH - enemy_size])
            y = random.randint(0, HEIGHT - enemy_size)
            enemies.append([x, y])

        # 4. Движение врагов
        for enemy in enemies:
            if enemy[0] < player_x:
                enemy[0] += enemy_speed
            elif enemy[0] > player_x:
                enemy[0] -= enemy_speed

            if enemy[1] < player_y:
                enemy[1] += enemy_speed
            elif enemy[1] > player_y:
                enemy[1] -= enemy_speed

        # 5. Проверка столкновений
        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        for enemy in enemies:
            enemy_rect = pygame.Rect(enemy[0], enemy[1], enemy_size, enemy_size)
            if player_rect.colliderect(enemy_rect):
                game_over = True  # Переключаемся на экран проигрыша

        # 6. Начисление очков
        score += 0.1

    # Отрисовка кадра
    screen.blit(background, (0, 0))
    screen.blit(player_img, (player_x, player_y))

    for enemy in enemies:
        screen.blit(enemy_img, (enemy[0], enemy[1]))

    # Текст счета и автора на экране
    text = font.render(f"Счет: {int(score)}", True, (255, 255, 255))
    screen.blit(text, (10, 10))

    author_text = font.render("Автор: Alnaz", True, (100, 100, 100))
    screen.blit(author_text, (WIDTH - 170, HEIGHT - 30))

    # ЭКРАН ПРОИГРЫША (если врезался враг)
    if game_over:
        # Рисуем красный текст по центру экрана
        go_text = game_over_font.render("ИГРА ОКОНЧЕНА", True, (255, 0, 0))
        # Математически ровно выравниваем текст по центру
        go_rect = go_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30))
        screen.blit(go_text, go_rect)

        # Подсказка для выхода
        hint_text = font.render("Нажмите любую клавишу для выхода", True, (200, 200, 200))
        hint_rect = hint_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 30))
        screen.blit(hint_text, hint_rect)

    # Обновление экрана
    pygame.display.flip()

# Выход
pygame.quit()
sys.exit()
